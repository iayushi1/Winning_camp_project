from tkinter import *
root = Tk()
root.geometry('600x400')
root.config(bg = 'lightgrey')
root.resizable(0,0)
root.title('DataFlair-AddressBook')

contactlist = [
    ['Ayushi','1234567890'],
    ['ABCD',  '1122334455'],
    ['EFGH',  '6677889900'],
    ['IJKL',  '1231231230'],
    ['MNOP',  '4564564560'],
    ['QRST' , '7897897890'],
    ['UVWX' , '0987654321'],
    ]

Name = StringVar()
Number = StringVar()

frame = Frame(root)
frame.pack(side = RIGHT)

scroll = Scrollbar(frame, orient=VERTICAL)
select = Listbox(frame, yscrollcommand=scroll.set, height=15)
scroll.config (command=select.yview)
scroll.pack(side=RIGHT, fill=Y)
select.pack(side=LEFT,  fill=BOTH, expand=1)
def Selected():
    return int(select.curselection()[0])

def AddContact():
    contactlist.append([Name.get(), Number.get()])
    Select_set()

def EDIT():
    contactlist[Selected()] = [Name.get(), Number.get()]
    Select_set()


def DELETE():
    del contactlist[Selected()]
    Select_set()

def VIEW():
    NAME, PHONE = contactlist[Selected()]
    Name.set(NAME)
    Number.set(PHONE)

def EXIT():
    root.destroy()

def RESET():
    Name.set('')
    Number.set('')

def Select_set() :
    contactlist.sort()
    select.delete(0,END)
    for name,phone in contactlist :
        select.insert (END, name)
Select_set()

Label(root, text = 'NAME', font='arial 12 bold', bg = 'Gray').place(x= 50, y=40)
Entry(root, textvariable = Name).place(x= 120, y=40)

Label(root, text = 'CONTACT NUMBER', font='arial 12 bold',bg = 'Gray').place(x= 280, y=40)
Entry(root, textvariable = Number).place(x= 460, y=40)

Button(root,text="ADD", font='arial 12 bold',bg='grey', command = AddContact).place(x= 50, y=90)
Button(root,text="EDIT", font='arial 12 bold',bg='grey',command = EDIT).place(x= 50, y=130)

Button(root,text="DELETE", font='arial 12 bold',bg='grey',command = DELETE).place(x= 50, y=170)
Button(root,text="VIEW", font='arial 12 bold',bg='grey', command = VIEW).place(x= 50, y=210)

Button(root,text="EXIT", font='arial 12 bold',bg='grey', command = EXIT).place(x= 50, y=290)
Button(root,text="RESET", font='arial 12 bold',bg='gray', command = RESET).place(x= 50, y=250)

root.mainloop()